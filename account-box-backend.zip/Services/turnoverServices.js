const turnoversModel = require("../models/turnovers");
const mongoose = require("mongoose");
const moment = require('moment');
const shopsModel = require("../models/shopsModel");

// Get All turnover 
exports.getAllturnovers = (req, res) => {
    turnoversModel.find({}, (error, result) => {
        if (error) {
            res.send(error)
        } else {
            res.send(result)
        }
    }).sort({ $natural: -1 })
    .populate('manager_id')
    .populate('shop_id')
    .populate('product_id')
    .populate('cashier_id')

}
// Get turnover 
exports.getSpecificturnover = (req, res) => {
    const turnoverId = req.params.turnoversId;
    turnoversModel.find({ _id: turnoverId }, function (err, foundResult) {
        try {
            res.json({ data: foundResult })
        } catch (err) {
            res.json(err)
        }
    }).populate('manager_id')
    .populate('shop_id')
    .populate('product_id')
    .populate('cashier_id')
}
// Get turnover by shop Id
exports.getTurnoverByShopId = (req, res) => {
    const ShopId = req.params.shop_id;
    turnoversModel.find({ shop_id: ShopId }, function (err, foundResult) {
        try {
            res.json({ data: foundResult,count:foundResult.length })
        } catch (err) {
            res.json(err)
        }
    }).populate('manager_id')
    .populate('shop_id')
    .populate('product_id')
    .populate('cashier_id')
}
// Get turnover by date
exports.getTurnoverByDate = (req, res) => {
    const Createddate = req.params.created_at;
    turnoversModel.find({ created_at: moment(Createddate).format("DD/MM/YYYY") }, function (err, foundResult) {
        try {
            res.json({ data: foundResult,count:foundResult.length })
        } catch (err) {
            res.json(err)
        }
    }).populate('manager_id')
    .populate('shop_id')
    .populate('product_id')
    .populate('cashier_id')
}
// Get turnover by date and product Id
exports.getTurnoverByDateAndProductId = (req, res) => {
    const Createddate = req.body.created_at;
    const productId = req.body.product_id;
    turnoversModel.find({ product_id:productId,created_at: moment(Createddate).format("DD/MM/YYYY") }, function (err, foundResult) {
        try {
            res.json({ data: foundResult,count:foundResult.length })
        } catch (err) {
            res.json(err)
        }
    }).populate('manager_id')
    .populate('shop_id')
    .populate('product_id')
    .populate('cashier_id')
}
// Get turnover by date and product Id
exports.getTurnoverByDateRangeAndProductId = (req, res) => {
    
    const data=turnoversModel.find({
        created_at: {
            $gt: req.body.startDate,
            $lt: req.body.endDate
        }
    })
    // const data=await turnoversModel.aggregate(
        // [ 
            
        // { 
        //     $group: {
        //         _id:  "$created_at"  , 
        //         count: { $sum: 1 }
        //     } 
        // },
        // {
        //     $sort: { "_id": 1 }
        // },
    //    { $match: {
    //     created_at: {
    //           $gte: "28/10/2022",
    //           $lte: "29/10/2022",
    //         },
    //       }
    //     },
        // { $unwind: "$created_at" }, 
        // { $match: {
        //         "created_at": {
        //               $gte: "27/10/2022",
        //               $lt: "29/10/2022",
        //             },
        //           }
        //         },
        // { $sortByCount: "$created_at" },
        // {$sort: {"_id": 1} }
        // { $sort: { created_at: -1 } }
    //  ] 
    // )
    res.json(data)
    // for(let article of data) {
    //     let dateArr = article._id.split('/');
    //     // Year, month, and day from the array. We subtract 1 from month, since months start counting from 0 in Javascript dates.
    //     let year = parseFloat(dateArr[2]);
    //     let month = parseFloat(dateArr[1]) - 1;
    //     let day = parseFloat(dateArr[0])
    //     // Pass in the different components as year, month, day to get the valid date
    //     let articleDate = new Date(year, month, day);
    //     // Update the object
    //     article._id = articleDate
    // }   
    
    // data.sort((a, b) => a._id - b._id);
    //   res.json(data)
  
}

// Delete 
exports.deleteturnover = (req, res) => {
    const turnoverId = req.params.turnoversId;
    turnoversModel.findByIdAndDelete(turnoverId, (error, result) => {
        if (error) {
            res.send({ message: error.message })
        } else {
            res.json({ message: "Deleted Successfully" })
        }
    })
}
// Delete All
exports.deleteAll = (req, res) => {
    turnoversModel.deleteMany({}, (error, result) => {
        if (error) {
            res.send(error)
            res.status(200).json({ result: error,error:true, message: "Some Error " ,statusCode:200})

        } else {
            res.status(200).json({ result: result,error:false, message: "All Record Deleted Successful " ,statusCode:200})

        }
    })
}
// Create 
exports.createturnover = async (req, res) => {
    const Createddate= req.body.created_at;
    shopsModel.find({ _id: req.body.shop_id}, (error, result) => {
        if (error) {
            res.send(error)
        } else {
            // res.send(result[0].manager_id)
            const ManagerId=result[0].manager_id
            if (result[0].manager_id === undefined || result[0].manager_id == '') {
                res.json({ data: result, message: "ManagerId not exist for this shop" })
            } else {
                const turnover = new turnoversModel({
                    _id: mongoose.Types.ObjectId(),
                    manager_id: ManagerId,
                    shop_id: req.body.shop_id,
                    product_id:req.body.product_id,
                    cashier_id:req.body.cashier_id,
                    amount: req.body.amount,
                    created_at:moment(Createddate).format("DD/MM/YYYY")

                });
                turnover.save((error, result) => {
                    if (error) {
                        res.send(error)
                    } else {
                        res.json({ data: result, message: "Created Successfully" })
                    }
                })

            }
        }
    })

}
// Update 
exports.updateturnover = async (req, res) => {
    const updateData = {
        amount: req.body.amount,
    }
    const options = {
        new: true
    }
    turnoversModel.findByIdAndUpdate(req.body._id, updateData, options, (error, result) => {
        if (error) {
            res.json(error.message)
        } else {
            res.send({ data: result, message: "Updated Successfully" })
        }
    })
}



